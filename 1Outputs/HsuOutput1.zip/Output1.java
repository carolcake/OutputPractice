public class Output1
{
	public static void main(String[] args)
	{
		System.out.println("My name is Caroline Hsu, pronounced shoe.");
		System.out.println("I am 15 years old.");
		System.out.println("My favorite food is ramen!");
		System.out.println("My favorite hobby is to listen to Taylor Swift or play golf!");
		System.out.println("My favorite movie is Mean Girls.");
	}
}