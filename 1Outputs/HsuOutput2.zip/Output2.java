public class Output2
{ 
	public static void main(String[] args)
	{
		System.out.println("       /\\   /\\         ⏜        /\\   /\\         ⏜");
		System.out.println("      (*  ▽  *)      /  /      (*  ▽  *)      /  /");
		System.out.println("      /   ‿   \\     /  /       /   ‿   \\     /  /");
		System.out.println("     /         \\   /  /       /         \\   /  /");
		System.out.println("    |           | /  /       |           | /  /");
		System.out.println("    |  ω     ω  |/  /        |  ω     ω  |/  /");
		System.out.println("    –––––––––––––  /         –––––––––––––  /");
	}
}